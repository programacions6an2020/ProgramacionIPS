<?php
 
require_once 'paciente_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $Paciente = new Paciente();
        $resultado = $Paciente->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $Paciente = new Paciente();
		$resultado = $Paciente->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$Paciente = new Paciente();
		$resultado = $Paciente->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $Paciente = new Paciente();
        $Paciente->consultar($datos['codigo']);

        if($Paciente->getpaci_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $Paciente->getpaci_codi(),
                'cedula' => $Paciente->getpaci_cedu(),
                'Paciente' => $Paciente->getpaci_nomb(),
                'edad' => $Paciente->getpaci_edad(),
                'telefono' =>$Paciente->getpaci_tel(),
                'direccion' =>$Paciente->getpaci_dir(),
                'email' =>$Paciente->getpaci_email(),
                'afiliado' => $Paciente->getafi_codi(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $Paciente = new Paciente();
        $listado = $Paciente->lista();
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);    
        break;
}
?>
