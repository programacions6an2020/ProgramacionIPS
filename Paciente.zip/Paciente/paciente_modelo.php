<?php
    require_once("../modeloAbstractoDB.php");
    class Paciente extends ModeloAbstractoDB {
		private $paci_codi;
		private $paci_cedu;
		private $paci_nomb;
		private $paci_edad;
		private $paci_tel;
		private $paci_dir;
		private $paci_email;
		private $afi_codi;
		

		function __construct() {
			//$this->db_name = '';
		}

		public function getpaci_codi(){
			return $this->paci_codi;
		}

		public function getpaci_nomb(){
			return $this->paci_nomb;
		}
		
		public function getpaci_edad(){
			return $this->paci_edad;
		}

		public function getpaci_cedu(){
			return $this->paci_cedu;
		}
		public function getpaci_tel(){
			return $this->paci_tel;
		}
		public function getafi_codi(){
			return $this->afi_codi;
		}
		public function getpaci_dir(){
			return $this->paci_dir;
		}
		public function getpaci_email(){
			return $this->paci_email;
		}

		public function consultar($paci_codi='') {
			if($paci_codi !=''):
				$this->query = "
				SELECT paci_codi, paci_cedu, paci_nomb, paci_edad,  paci_tel, paci_dir, paci_email, afi_codi  
				FROM tb_paciente
				WHERE paci_codi = '$paci_codi' order by paci_codi
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT paci_codi, paci_cedu, paci_nomb, paci_edad,  paci_tel, paci_dir, paci_email, m.afi_est 
			FROM tb_paciente as c inner join tb_afiliado as m
			ON (c.afi_codi = m.afi_codi) order by paci_codi
			";
			
			$this->obtener_resultados_query();
			return $this->rows;
			
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('paci_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$paci_nomb= utf8_decode($paci_nomb);
				$this->query = "
					INSERT INTO tb_paciente
					(paci_codi, paci_cedu, paci_nomb, paci_edad,  paci_tel, paci_dir, paci_email, afi_codi)
					VALUES
					(NULL, '$paci_cedu', '$paci_nomb', '$paci_edad', '$paci_tel', '$paci_dir', '$paci_email', '$afi_codi')
					";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$paci_nomb= utf8_decode($paci_nomb);
			$paci_codi= utf8_decode($paci_codi);
			$paci_edad= utf8_decode($paci_edad);
			$paci_cedu= utf8_decode($paci_cedu);
			$paci_tel= utf8_decode($paci_tel);
			$afi_codi= utf8_decode($afi_codi);
			$paci_dir= utf8_decode($paci_dir);
			$paci_email= utf8_decode($paci_email);
			$this->query = "
			UPDATE tb_paciente
			SET paci_cedu='$paci_cedu',
			paci_nomb='$paci_nomb',
			paci_edad='$paci_edad',
			paci_tel='$paci_tel',
			paci_dir='$paci_dir',
			paci_email='$paci_email',
			afi_codi='$afi_codi'  
			WHERE paci_codi = '$paci_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($paci_codi='') {
			$this->query = "
			DELETE FROM tb_paciente
			WHERE paci_codi = '$paci_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>