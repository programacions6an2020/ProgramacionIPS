<?php
	require_once('../modeloAbstractoDB.php');
	class Especialista extends ModeloAbstractoDB {
		public $espe_codi;
		public $espe_nomb;
		public $espe_edad;
		public $espe_tel;
		public $espe_cel;
		public $espe_dir;
		public $espe_email;
		
		
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getespe_codi(){
			return $this->espe_codi;
		}

		public function getespe_nomb(){
			return $this->espe_nomb;
		}

		public function getespe_edad(){
			return $this->espe_edad;
		}

		public function getespe_tel(){
			return $this->espe_tel;
		}

		public function getespe_cel(){
			return $this->espe_cel;
		}

		public function getespe_dir(){
			return $this->espe_dir;
		}

		public function getespe_email(){
			return $this->espe_email;
		}


		
		

		public function consultar($espe_codi='') {
			if($espe_codi != ''):
				$this->query = "
				SELECT espe_codi, espe_nomb, espe_edad, espe_tel, espe_cel, espe_dir, espe_email 
				FROM tb_especialista
				WHERE espe_codi = '$espe_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT espe_codi, espe_nomb, espe_edad, espe_tel, espe_cel, espe_dir, espe_email  
			FROM tb_especialista ORDER BY espe_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		/*
		public function listapais() {
			$this->query = "
			SELECT espe_codi, espe_nomb 
			FROM tb_especialista as d order by espe_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}*/
		
		public function nuevo($datos=array()) {
			if(array_key_exists('espe_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_especialista
				(espe_codi, espe_nomb, espe_edad, espe_tel, espe_cel, espe_dir, espe_email )
				VALUES
				('$espe_codi', '$espe_nomb', '$espe_edad', '$espe_tel', '$espe_cel', '$espe_dir', '$espe_email' )
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$espe_nomb= utf8_decode($espe_nomb);
			$espe_codi= utf8_decode($espe_codi);
			$espe_edad= utf8_decode($espe_edad);
			$espe_tel= utf8_decode($espe_tel);
			$espe_cel= utf8_decode($espe_cel);
			$espe_dir= utf8_decode($espe_dir);
			$espe_email= utf8_decode($espe_email);
			
			$this->query = "
			UPDATE tb_especialista
			SET espe_nomb='$espe_nomb',
			espe_edad='$espe_edad',
			espe_tel='$espe_tel',
			espe_cel='$espe_cel',
			espe_dir='$espe_dir',
			espe_email='$espe_email' 
			WHERE espe_codi = '$espe_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($espe_codi='') {
			$this->query = "
			DELETE FROM tb_especialista
			WHERE espe_codi = '$espe_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>