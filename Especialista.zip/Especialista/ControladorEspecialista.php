<?php
 
require_once 'especialista_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $especialista = new Especialista();
        $resultado = $especialista->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $especialista = new Especialista();
        $resultado = $especialista->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $especialista = new Especialista();
        $resultado = $especialista->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $especialista = new Especialista();
        $especialista->consultar($datos['codigo']);

        if($especialista->getespe_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $especialista->getespe_codi(),
                'Especialista' => $especialista->getespe_nomb(),
                'edad' => $especialista->getespe_edad(),
                'telefono' => $especialista->getespe_tel(),
                'celular' => $especialista->getespe_cel(),
                'direccion' => $especialista->getespe_dir(),
                'email' => $especialista->getespe_email(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $especialista = new Especialista();
        $listado = $especialista->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
