<?php
require('../fpdf.php');
// $informacion=$_GET;
// var_dump($informacion);
class PDF extends FPDF
{
// Cabecera de p�gina
function Header()
{
    // Logo
    $this->Image('../img/logo.jpg',10,3,22);
    // Arial bold 15
    $this->SetFont('Arial','B',10);
    // Movernos a la derecha
    #$this->Cell(60);
    // T�tulo
    $this->Cell(0,20,'LISTADO DE PACIENTES',0,0,'C');
    $this->Cell(-40, 10, 'Fecha: '.date('d-m-Y').'',0,0,'C');
    // Salto de l�nea
    $this->Ln(20);
  
}

// Pie de p�gina
function Footer()
{
    // Posici�n: a 1,5 cm del final
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // N�mero de p�gina
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',1,0,'C');
}

// Cargar los datos
function cargarDatos()
{
    $db = mysqli_connect("localhost","root","","ips"); //keep your db name
    $query = "
    SELECT paci_codi, paci_cedu, paci_nomb, paci_edad,  paci_tel, paci_dir, paci_email, m.afi_est 
            FROM tb_paciente as c inner join tb_afiliado as m
            ON (c.afi_codi = m.afi_codi) order by paci_codi
    ";
    $sth = $db->query($query);
    while ($fila = $sth->fetch_assoc()){
        $rows[] = array_map('utf8_encode',$fila);
    }
    // var_dump($rows);
    return $rows;
    
    // Leer las l�neas del fichero
}

// Tabla Elegante
function TablaElegante($titulos, $datos)
{
    // Colores, ancho de l�nea y fuente en negrita
    $this->SetFillColor(0, 0, 0 );
    $this->SetTextColor(255);
    $this->SetDrawColor(0, 0, 0 );
    $this->SetLineWidth(.2);
    $this->SetFont('','B',12);
    // Cabecera de titulos
    $w = array(10,40,25,25,40,50);
    for($i=0;$i<count($titulos);$i++)
        $this->Cell($w[$i],5,$titulos[$i],1,0,'C',true);
    $this->Ln();
    // Restauraci�n de colores y fuentes
    $this->SetFillColor(132, 192, 245);
    $this->SetTextColor(0);
    $this->SetFont('','',10);
    // Datos
    $fill = false;
    // while ($row = $datos->fetch_assoc()) {
    //     $this->Cell($w[0],6,$row[0],'LR',0,'L',$fill);
    //     $this->Cell($w[1],6,$row[1],'LR',0,'L',$fill);
    //     $this->Cell($w[2],6,number_format($row[2]),'LR',0,'R',$fill);
	// 	$this->Cell($w[3],6,number_format($row[3]),'LR',0,'R',$fill);
    //     $this->Ln();
    //     $fill = !$fill;
    // }
    foreach($datos as $row)
    {
        // var_dump($datos);
        $this->Cell($w[0],5,$row['paci_codi'],'LR',0,'C',$fill);
        $this->Cell($w[1],5,$row['paci_nomb'],'LR',0,'C',$fill);
        $this->Cell($w[2],5,$row['paci_edad'],'LR',0,'C',$fill);
        $this->Cell($w[3],5,$row['paci_tel'],'LR',0,'C',$fill);
        $this->Cell($w[4],5,$row['paci_email'],'LR',0,'C',$fill);
        $this->Cell($w[5],5,$row['afi_est'],'LR',0,'C',$fill);
        
        $this->Ln();
        $fill = !$fill;
    }
    // L�nea de cierre
    $this->Cell(array_sum($w),0,'','T');
}
}

// Creaci�n del objeto de la clase heredada
$pdf = new PDF();
$pdf->AliasNbPages();
// T�tulos de las columnas
$titulos = array('ID', 'Nombre', 'Edad', 'Telefono', 'Direccion', 'Email');
// Carga de datos
$datos = $pdf->cargarDatos();
// $datos = array('ID', 'Empleado', 'Valor', 'Tienda', 'Dias laborados');
$pdf->SetFont('Arial','',2);
$pdf->AddPage();
// $pdf->TablaBasica($titulos,$datos);

#$pdf->TablaMejorada($titulos,$datos);

$pdf->TablaElegante($titulos,$datos);
$pdf->Output();
?>