var dt;

function Especialista(){
    $("#contenido").on("click","button#actualizar",function(){
         var datos=$("#fEspecialista").serialize();
         $.ajax({
            type:"get",
            url:"./php/Especialista/ControladorEspecialista.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Actualizado!',
                    'Se actaulizaron los datos correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado Especialista");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#Especialista").removeClass("hide");
                $("#Especialista").addClass("show")
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    })

    $("#contenido").on("click","a.borrar",function(){
        //Recupera datos del formulario
        var codigo = $(this).data("codigo");

        swal({
              title: '¿Está seguro?',
              text: "¿Realmente desea borrar el Especialista con codigo : " + codigo + " ?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Si, Borrarlo!'
        }).then((decision) => {
                if (decision.value) {

                    var request = $.ajax({
                        method: "get",
                        url: "./php/Especialista/ControladorEspecialista.php",
                        data: {codigo: codigo, accion:'borrar'},
                        dataType: "json"
                    })

                    request.done(function( resultado ) {
                        if(resultado.respuesta == 'correcto'){
                            swal(
                                'Borrado!',
                                'El Especialista con codigo : ' + codigo + ' fue borrado',
                                'success'
                            )     
                            dt.ajax.reload();                            
                        } else {
                            swal({
                              type: 'error',
                              title: 'Oops...',
                              text: 'Something went wrong!'                         
                            })
                        }
                    });
                     
                    request.fail(function( jqXHR, textStatus ) {
                        swal({
                          type: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!' + textStatus                          
                        })
                    });
                }
        })

    });

    $("#contenido").on("click","button.btncerrar2",function(){
        $("#titulo").html("Listado Especialistaes");
        $("#nuevo-editar").html("");
        $("#nuevo-editar").removeClass("show");
        $("#nuevo-editar").addClass("hide");
        $("#Especialista").removeClass("hide");
        $("#Especialista").addClass("show");

    })

    $("#contenido").on("click","button.btncerrar",function(){
        $("#contenedor").removeClass("show");
        $("#contenedor").addClass("hide");
        $("#contenido").html('')
    })

    $("#contenido").on("click","button#nuevo",function(){
        $("#titulo").html("Nuevo Especialista");
        $("#nuevo-editar" ).load("./php/Especialista/nuevoEspecialista.php"); 
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#Especialista").removeClass("show");
        $("#Especialista").addClass("hide");
    })

    $("#contenido").on("click","button#grabar",function(){
        /*var comu_codi = $("#comu_codi").attr("value");
        var comu_nomb = $("#comu_nomb").attr("value");
        var muni_codi = $("#muni_codi").attr("value");
        var datos = "comu_codi="+comu_codi+"&comu_nomb="+comu_nomb+"&muni_codi="+muni_codi;*/
      
      var datos=$("#fEspecialista").serialize();
       $.ajax({
            type:"get",
            url:"./php/Especialista/ControladorEspecialista.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Grabado!!',
                    'El registro se grabó correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado Especialistaes");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#Especialista").removeClass("hide");
                $("#Especialista").addClass("show")
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    });


    $("#contenido").on("click","a.editar",function(){
       $("#titulo").html("Editar Especialista");
       //Recupera datos del fromulario
       var codigo = $(this).data("codigo");
       var Especialista;
        $("#nuevo-editar").load("./php/Especialista/editarEspecialista.php");
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#Especialista").removeClass("show");
        $("#Especialista").addClass("hide");
       $.ajax({
           type:"get",
           url:"./php/Especialista/ControladorEspecialista.php",
           data: {codigo: codigo, accion:'consultar'},
           dataType:"json"
           }).done(function( Especialista ) {        
                if(Especialista.respuestas === "no existe"){
                    swal({
                      type: 'error',
                      title: 'Oops...',
                      text: 'Especialista no existe!!!!!'                         
                    })
                } else {
                    $("#espe_codi").val(Especialista.codigo);                   
                    $("#espe_nomb").val(Especialista.Especialista);
                    $("#espe_edad").val(Especialista.edad);
                    $("#espe_tel").val(Especialista.telefono);
                    $("#espe_cel").val(Especialista.celular);
                    $("#espe_dir").val(Especialista.direccion);
                    $("#espe_email").val(Especialista.email);
                }
           });

          

       })
}
            


$(document).ready(() => {
  $("#contenido").off("click", "a.editar");
  $("#contenido").off("click", "button#actualizar");
  $("#contenido").off("click","a.borrar");
  $("#contenido").off("click","button#nuevo");
  $("#contenido").off("click","button#grabar");
  $("#titulo").html("Listado de Especialistaes");
  dt = $("#tabla").DataTable({
        "ajax": "php/Especialista/ControladorEspecialista.php?accion=listar",
        "columns": [
            { "data": "espe_codi"} ,
            { "data": "espe_nomb" },
            { "data": "espe_edad" },
            { "data": "espe_tel" },
            { "data": "espe_cel" },
            { "data": "espe_dir" },
            { "data": "espe_email" },
            { "data": "espe_codi",
                render: function (data) {
                          return '<a href="#" data-codigo="'+ data + 
                                 '" class="btn btn-danger btn-sm borrar"> <i class="fa fa-trash"></i></a>' 
                }
            },
            { "data": "espe_codi",
                render: function (data) {
                          return '<a href="#" data-codigo="'+ data + 
                                 '" class="btn btn-info btn-sm editar"> <i class="fa fa-edit"></i></a>';
                }
            }
        ]
  });
  Especialista();
});