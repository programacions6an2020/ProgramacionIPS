var dt;

function Asesor(){
    $("#contenido").on("click","button#actualizar",function(){
         var datos=$("#fAsesor").serialize();
         $.ajax({
            type:"get",
            url:"./php/Asesor/ControladorAsesor.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Actualizado!',
                    'Se actaulizaron los datos correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado Asesor");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#Asesor").removeClass("hide");
                $("#Asesor").addClass("show")
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    })

    $("#contenido").on("click","a.borrar",function(){
        //Recupera datos del formulario
        var codigo = $(this).data("codigo");

        swal({
              title: '¿Está seguro?',
              text: "¿Realmente desea borrar el Asesor con codigo : " + codigo + " ?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Si, Borrarlo!'
        }).then((decision) => {
                if (decision.value) {

                    var request = $.ajax({
                        method: "get",
                        url: "./php/Asesor/ControladorAsesor.php",
                        data: {codigo: codigo, accion:'borrar'},
                        dataType: "json"
                    })

                    request.done(function( resultado ) {
                        if(resultado.respuesta == 'correcto'){
                            swal(
                                'Borrado!',
                                'El Asesor con codigo : ' + codigo + ' fue borrado',
                                'success'
                            )     
                            dt.ajax.reload();                            
                        } else {
                            swal({
                              type: 'error',
                              title: 'Oops...',
                              text: 'Something went wrong!'                         
                            })
                        }
                    });
                     
                    request.fail(function( jqXHR, textStatus ) {
                        swal({
                          type: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!' + textStatus                          
                        })
                    });
                }
        })

    });

    $("#contenido").on("click","button.btncerrar2",function(){
        $("#titulo").html("Listado Asesores");
        $("#nuevo-editar").html("");
        $("#nuevo-editar").removeClass("show");
        $("#nuevo-editar").addClass("hide");
        $("#Asesor").removeClass("hide");
        $("#Asesor").addClass("show");

    })

    $("#contenido").on("click","button.btncerrar",function(){
        $("#contenedor").removeClass("show");
        $("#contenedor").addClass("hide");
        $("#contenido").html('')
    })

    $("#contenido").on("click","button#nuevo",function(){
        $("#titulo").html("Nuevo Asesor");
        $("#nuevo-editar" ).load("./php/Asesor/nuevoAsesor.php"); 
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#Asesor").removeClass("show");
        $("#Asesor").addClass("hide");
    })

    $("#contenido").on("click","button#grabar",function(){
        /*var comu_codi = $("#comu_codi").attr("value");
        var comu_nomb = $("#comu_nomb").attr("value");
        var muni_codi = $("#muni_codi").attr("value");
        var datos = "comu_codi="+comu_codi+"&comu_nomb="+comu_nomb+"&muni_codi="+muni_codi;*/
      
      var datos=$("#fAsesor").serialize();
       $.ajax({
            type:"get",
            url:"./php/Asesor/ControladorAsesor.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Grabado!!',
                    'El registro se grabó correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado Asesores");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#Asesor").removeClass("hide");
                $("#Asesor").addClass("show")
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    });


    $("#contenido").on("click","a.editar",function(){
       $("#titulo").html("Editar Asesor");
       //Recupera datos del fromulario
       var codigo = $(this).data("codigo");
       var Asesor;
        $("#nuevo-editar").load("./php/Asesor/editarAsesor.php");
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#Asesor").removeClass("show");
        $("#Asesor").addClass("hide");
       $.ajax({
           type:"get",
           url:"./php/Asesor/ControladorAsesor.php",
           data: {codigo: codigo, accion:'consultar'},
           dataType:"json"
           }).done(function( Asesor ) {        
                if(Asesor.respuestas === "no existe"){
                    swal({
                      type: 'error',
                      title: 'Oops...',
                      text: 'Asesor no existe!!!!!'                         
                    })
                } else {
                    $("#ase_codi").val(Asesor.codigo);                   
                    $("#ase_nomb").val(Asesor.Asesor);
                    $("#ase_edad").val(Asesor.edad);
                    $("#ase_tel").val(Asesor.telefono);
                    $("#ase_dir").val(Asesor.direccion);
                    $("#ase_email").val(Asesor.email);
                }
           });

          

       })
}
            


$(document).ready(() => {
  $("#contenido").off("click", "a.editar");
  $("#contenido").off("click", "button#actualizar");
  $("#contenido").off("click","a.borrar");
  $("#contenido").off("click","button#nuevo");
  $("#contenido").off("click","button#grabar");
  $("#titulo").html("Listado de Asesores");
  dt = $("#tabla").DataTable({
        "ajax": "php/Asesor/ControladorAsesor.php?accion=listar",
        "columns": [
            { "data": "ase_codi"} ,
            { "data": "ase_nomb" },
            { "data": "ase_edad" },
            { "data": "ase_tel" },
            { "data": "ase_dir" },
            { "data": "ase_email" },
            { "data": "ase_codi",
                render: function (data) {
                          return '<a href="#" data-codigo="'+ data + 
                                 '" class="btn btn-danger btn-sm borrar"> <i class="fa fa-trash"></i></a>' 
                }
            },
            { "data": "ase_codi",
                render: function (data) {
                          return '<a href="#" data-codigo="'+ data + 
                                 '" class="btn btn-info btn-sm editar"> <i class="fa fa-edit"></i></a>';
                }
            }
        ]
  });
  Asesor();
});