var dt;

function Cita(){
    $("#contenido").on("click","button#actualizar",function(){
         var datos=$("#fCita").serialize();
         $.ajax({
            type:"get",
            url:"./php/Cita/controladorCita.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Actualizado!',
                    'Se actaulizaron los datos correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado Citaes");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#Cita").removeClass("hide");
                $("#Cita").addClass("show")
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    })

    $("#contenido").on("click","a.borrar",function(){
        //Recupera datos del formulario
        var codigo = $(this).data("codigo");

        swal({
              title: '¿Está seguro?',
              text: "¿Realmente desea borrar la Cita con codigo : " + codigo + " ?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Si, Borrarlo!'
        }).then((decision) => {
                if (decision.value) {

                    var request = $.ajax({
                        method: "get",
                        url: "./php/Cita/controladorCita.php",
                        data: {codigo: codigo, accion:'borrar'},
                        dataType: "json"
                    })

                    request.done(function( resultado ) {
                        if(resultado.respuesta == 'correcto'){
                            swal(
                                'Borrado!',
                                'La Cita con codigo : ' + codigo + ' fue borrada',
                                'success'
                            )     
                            dt.ajax.reload();                            
                        } else {
                            swal({
                              type: 'error',
                              title: 'Oops...',
                              text: 'Something went wrong!'                         
                            })
                        }
                    });
                     
                    request.fail(function( jqXHR, textStatus ) {
                        swal({
                          type: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!' + textStatus                          
                        })
                    });
                }
        })

    });

    $("#contenido").on("click","button.btncerrar2",function(){
        $("#titulo").html("Listado Citaes");
        $("#nuevo-editar").html("");
        $("#nuevo-editar").removeClass("show");
        $("#nuevo-editar").addClass("hide");
        $("#Cita").removeClass("hide");
        $("#Cita").addClass("show");

    })

    $("#contenido").on("click","button.btncerrar",function(){
        $("#contenedor").removeClass("show");
        $("#contenedor").addClass("hide");
        $("#contenido").html('')
    })

    $("#contenido").on("click","button#nuevo",function(){
        $("#titulo").html("Nueva Cita");
        $("#nuevo-editar" ).load("./php/Cita/nuevoCita.php"); 
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#Cita").removeClass("show");
        $("#Cita").addClass("hide");
         $.ajax({ //Asesores
             type:"get",
             url:"./php/Asesor/controladorAsesor.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {   
              $("#ase_codi option").remove()       
              $("#ase_codi").append("<option selecte value=''>Seleccione un Asesor</option>")
              $.each(resultado.data, function (index, value) { 
                $("#ase_codi").append("<option value='" + value.ase_codi + "'>" + value.ase_nomb + "</option>")
              });
           });

           $.ajax({ //Pacientes
             type:"get",
             url:"./php/Paciente/controladorPaciente.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {   
              $("#paci_codi option").remove()       
              $("#paci_codi").append("<option selecte value=''>Seleccione un Paciente</option>")
              $.each(resultado.data, function (index, value) { 
                $("#paci_codi").append("<option value='" + value.paci_codi + "'>" + value.paci_nomb + "</option>")
              });
           });

           $.ajax({ //Medicos
             type:"get",
             url:"./php/Medico/controladorMedico.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {   
              $("#medi_codi option").remove()       
              $("#medi_codi").append("<option selecte value=''>Seleccione un Medico</option>")
              $.each(resultado.data, function (index, value) { 
                $("#medi_codi").append("<option value='" + value.medi_codi + "'>" + value.medi_nomb + "</option>")
              });
           });

           $.ajax({ //Especialista
             type:"get",
             url:"./php/Especialista/controladorEspecialista.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {   
              $("#espe_codi option").remove()       
              $("#espe_codi").append("<option selecte value=''>Seleccione un Especialista</option>")
              $.each(resultado.data, function (index, value) { 
                $("#espe_codi").append("<option value='" + value.espe_codi + "'>" + value.espe_nomb + "</option>")
              });
           });

           $.ajax({ //Sede
             type:"get",
             url:"./php/Sede/controladorSede.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {   
              $("#sede_codi option").remove()       
              $("#sede_codi").append("<option selecte value=''>Seleccione una Sede</option>")
              $.each(resultado.data, function (index, value) { 
                $("#sede_codi").append("<option value='" + value.sede_codi + "'>" + value.sede_nomb + "</option>")
              });
           });

           $.ajax({ //Servicios
             type:"get",
             url:"./php/Servicio/controladorServicio.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {   
              $("#servi_codi option").remove()       
              $("#servi_codi").append("<option selecte value=''>Seleccione un Servicio</option>")
              $.each(resultado.data, function (index, value) { 
                $("#servi_codi").append("<option value='" + value.servi_codi + "'>" + value.servi_nomb + "</option>")
              });
           });


    })

    $("#contenido").on("click","button#grabar",function(){
      
      var datos=$("#fCita").serialize();
       $.ajax({
            type:"get",
            url:"./php/Cita/controladorCita.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Grabado!!',
                    'El registro se grabó correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado Citaes");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#Cita").removeClass("hide");
                $("#Cita").addClass("show")
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    });


    $("#contenido").on("click","a.editar",function(){
       $("#titulo").html("Editar Cita");
       //Recupera datos del fromulario
       var codigo = $(this).data("codigo");
       var Asesor;
       var Paciente;
       var Medico;
       var Especialista;
       var Sede;
       var Servicio;
        $("#nuevo-editar").load("./php/Cita/editarCita.php");
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#Cita").removeClass("show");
        $("#Cita").addClass("hide");
       $.ajax({
           type:"get",
           url:"./php/Cita/controladorCita.php",
           data: {codigo: codigo, accion:'consultar'},
           dataType:"json"
           }).done(function( Cita ) {        
                if(Cita.respuesta === "no existe"){
                    swal({
                      type: 'error',
                      title: 'Oops...',
                      text: 'Cita no existe!!!!!'                         
                    })
                } else {
                    $("#cita_codi").val(Cita.codigo);                   
                    Asesor = Cita.asesor;
                    Paciente = Cita.paciente;
                    Medico = Cita.medico;
                    Especialista = Cita.especialista;
                    Sede = Cita.sede;
                    Servicio = Cita.servicio;
                    $("#cita_desc").val(Cita.descripcion); 

                }
           });

           $.ajax({// Asesor
             type:"get",
             url:"./php/Asesor/controladorAsesor.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {                     
              $("#ase_codi option").remove();
              $.each(resultado.data, function (index, value) { 
                
                if(Asesor === value.ase_codi){
                  $("#ase_codi").append("<option selected value='" + value.ase_codi + "'>" + value.ase_nomb + "</option>")
                }else {
                  $("#ase_codi").append("<option value='" + value.ase_codi + "'>" + value.ase_nomb + "</option>")
                }
              });
           });    

           $.ajax({//Pacientes
             type:"get",
             url:"./php/Paciente/controladorPaciente.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {                     
              $("#paci_codi option").remove();
              $.each(resultado.data, function (index, value) { 
                
                if(Paciente === value.paci_codi){
                  $("#paci_codi").append("<option selected value='" + value.paci_codi + "'>" + value.paci_nomb + "</option>")
                }else {
                  $("#paci_codi").append("<option value='" + value.paci_codi + "'>" + value.paci_nomb + "</option>")
                }
              });
           }); 
           //-

           $.ajax({//Medicos
             type:"get",
             url:"./php/Medico/controladorMedico.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {                     
              $("#medi_codi option").remove();
              $.each(resultado.data, function (index, value) { 
                
                if(Medico === value.medi_codi){
                  $("#medi_codi").append("<option selected value='" + value.medi_codi + "'>" + value.medi_nomb + "</option>")
                }else {
                  $("#medi_codi").append("<option value='" + value.medi_codi + "'>" + value.medi_nomb + "</option>")
                }
              });
           }); 
           //-

           $.ajax({//Especialista
             type:"get",
             url:"./php/Especialista/controladorEspecialista.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {                     
              $("#espe_codi option").remove();
              $.each(resultado.data, function (index, value) { 
                
                if(Especialista === value.espe_codi){
                  $("#espe_codi").append("<option selected value='" + value.espe_codi + "'>" + value.espe_nomb + "</option>")
                }else {
                  $("#espe_codi").append("<option value='" + value.espe_codi + "'>" + value.espe_nomb + "</option>")
                }
              });
           }); 
           //-

           $.ajax({//Sede
             type:"get",
             url:"./php/Sede/controladorSede.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {                     
              $("#sede_codi option").remove();
              $.each(resultado.data, function (index, value) { 
                
                if(Sede === value.sede_codi){
                  $("#sede_codi").append("<option selected value='" + value.sede_codi + "'>" + value.sede_nomb + "</option>")
                }else {
                  $("#sede_codi").append("<option value='" + value.sede_codi + "'>" + value.sede_nomb + "</option>")
                }
              });
           }); 
           //-

           $.ajax({//Servicios
             type:"get",
             url:"./php/Servicio/controladorServicio.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {                     
              $("#servi_codi option").remove();
              $.each(resultado.data, function (index, value) { 
                
                if(Servicio === value.servi_codi){
                  $("#servi_codi").append("<option selected value='" + value.servi_codi + "'>" + value.servi_nomb + "</option>")
                }else {
                  $("#servi_codi").append("<option value='" + value.servi_codi + "'>" + value.servi_nomb + "</option>")
                }
              });
           }); 
           //-
            
       })
}

$(document).ready(() => {
  $("#contenido").off("click", "a.editar");
  $("#contenido").off("click", "button#actualizar");
  $("#contenido").off("click","a.borrar");
  $("#contenido").off("click","button#nuevo");
  $("#contenido").off("click","button#grabar");
  $("#titulo").html("Listado de Citaes");
  dt = $("#tabla").DataTable({
        "ajax": "php/Cita/controladorCita.php?accion=listar",
        "columns": [
            { "data": "cita_codi"} ,
            { "data": "ase_nomb" },
            { "data": "paci_nomb" },
            { "data": "medi_nomb" },
            { "data": "espe_nomb" },
            { "data": "sede_nomb" },
            { "data": "servi_nomb" },
            { "data": "cita_desc"},
            { "data": "cita_codi",
                render: function (data) {
                          return '<a href="#" data-codigo="'+ data + 
                                 '" class="btn btn-danger btn-sm borrar"> <i class="fa fa-trash"></i></a>' 
                }
            },
            { "data": "cita_codi",
                render: function (data) {
                          return '<a href="#" data-codigo="'+ data + 
                                 '" class="btn btn-info btn-sm editar"> <i class="fa fa-edit"></i></a>';
                }
            }
        ]
  });
  Cita();
});