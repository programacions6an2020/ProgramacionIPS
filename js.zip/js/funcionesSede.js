var dt;

function Sede(){
    $("#contenido").on("click","button#actualizar",function(){
         var datos=$("#fSede").serialize();
         $.ajax({
            type:"get",
            url:"./php/Sede/controladorSede.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Actualizado!',
                    'Se actaulizaron los datos correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado Sedees");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#Sede").removeClass("hide");
                $("#Sede").addClass("show")
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    })

    $("#contenido").on("click","a.borrar",function(){
        //Recupera datos del formulario
        var codigo = $(this).data("codigo");

        swal({
              title: '¿Está seguro?',
              text: "¿Realmente desea borrar la Sede con codigo : " + codigo + " ?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Si, Borrarlo!'
        }).then((decision) => {
                if (decision.value) {

                    var request = $.ajax({
                        method: "get",
                        url: "./php/Sede/controladorSede.php",
                        data: {codigo: codigo, accion:'borrar'},
                        dataType: "json"
                    })

                    request.done(function( resultado ) {
                        if(resultado.respuesta == 'correcto'){
                            swal(
                                'Borrado!',
                                'La Sede con codigo : ' + codigo + ' fue borrada',
                                'success'
                            )     
                            dt.ajax.reload();                            
                        } else {
                            swal({
                              type: 'error',
                              title: 'Oops...',
                              text: 'Something went wrong!'                         
                            })
                        }
                    });
                     
                    request.fail(function( jqXHR, textStatus ) {
                        swal({
                          type: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!' + textStatus                          
                        })
                    });
                }
        })

    });

    $("#contenido").on("click","button.btncerrar2",function(){
        $("#titulo").html("Listado Sedees");
        $("#nuevo-editar").html("");
        $("#nuevo-editar").removeClass("show");
        $("#nuevo-editar").addClass("hide");
        $("#Sede").removeClass("hide");
        $("#Sede").addClass("show");

    })

    $("#contenido").on("click","button.btncerrar",function(){
        $("#contenedor").removeClass("show");
        $("#contenedor").addClass("hide");
        $("#contenido").html('')
    })

    $("#contenido").on("click","button#nuevo",function(){
        $("#titulo").html("Nueva Sede");
        $("#nuevo-editar" ).load("./php/Sede/nuevoSede.php"); 
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#Sede").removeClass("show");
        $("#Sede").addClass("hide");
         $.ajax({
             type:"get",
             url:"./php/Ciudad/controladorCiudad.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {   
              //console.log(resultado.data)           
              $("#ciu_codi option").remove()       
              $("#ciu_codi").append("<option selecte value=''>Seleccione una Ciudad</option>")
              $.each(resultado.data, function (index, value) { 
                $("#ciu_codi").append("<option value='" + value.ciu_codi + "'>" + value.ciu_nomb + "</option>")
              });
           });
    })

    $("#contenido").on("click","button#grabar",function(){
      
      var datos=$("#fSede").serialize();
       $.ajax({
            type:"get",
            url:"./php/Sede/controladorSede.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Grabado!!',
                    'El registro se grabó correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado Sedees");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#Sede").removeClass("hide");
                $("#Sede").addClass("show")
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    });


    $("#contenido").on("click","a.editar",function(){
       $("#titulo").html("Editar Sede");
       //Recupera datos del fromulario
       var codigo = $(this).data("codigo");
       var ciudad;
        $("#nuevo-editar").load("./php/Sede/editarSede.php");
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#Sede").removeClass("show");
        $("#Sede").addClass("hide");
       $.ajax({
           type:"get",
           url:"./php/Sede/controladorSede.php",
           data: {codigo: codigo, accion:'consultar'},
           dataType:"json"
           }).done(function( Sede ) {        
                if(Sede.respuesta === "no existe"){
                    swal({
                      type: 'error',
                      title: 'Oops...',
                      text: 'Sede no existe!!!!!'                         
                    })
                } else {
                    $("#sede_codi").val(Sede.codigo);                   
                    $("#sede_nomb").val(Sede.sede);
                    ciudad = Sede.ciudad;
                }
           });

           $.ajax({
             type:"get",
             url:"./php/Ciudad/controladorCiudad.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {                     
              $("#ciu_codi option").remove();
              $.each(resultado.data, function (index, value) { 
                
                if(ciudad === value.ciu_codi){
                  $("#ciu_codi").append("<option selected value='" + value.ciu_codi + "'>" + value.ciu_nomb + "</option>")
                }else {
                  $("#ciu_codi").append("<option value='" + value.ciu_codi + "'>" + value.ciu_nomb + "</option>")
                }
              });
           });    
            
       })
}

$(document).ready(() => {
  $("#contenido").off("click", "a.editar");
  $("#contenido").off("click", "button#actualizar");
  $("#contenido").off("click","a.borrar");
  $("#contenido").off("click","button#nuevo");
  $("#contenido").off("click","button#grabar");
  $("#titulo").html("Listado de Sedees");
  dt = $("#tabla").DataTable({
        "ajax": "php/Sede/controladorSede.php?accion=listar",
        "columns": [
            { "data": "sede_codi"} ,
            { "data": "sede_nomb"},
            { "data": "ciu_nomb" },
            { "data": "sede_codi",
                render: function (data) {
                          return '<a href="#" data-codigo="'+ data + 
                                 '" class="btn btn-danger btn-sm borrar"> <i class="fa fa-trash"></i></a>' 
                }
            },
            { "data": "sede_codi",
                render: function (data) {
                          return '<a href="#" data-codigo="'+ data + 
                                 '" class="btn btn-info btn-sm editar"> <i class="fa fa-edit"></i></a>';
                }
            }
        ]
  });
  Sede();
});