<?php
	require_once('../modeloAbstractoDB.php');
	class Cita extends ModeloAbstractoDB {
		public $cita_codi;
		public $ase_codi;
		public $paci_codi;
		public $medi_codi;
		public $espe_codi;
		public $sede_codi;
		public $servi_codi;
		public $cita_desc;
		
		
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getcita_codi(){
			return $this->cita_codi;
		}

		public function getase_codi(){
			return $this->ase_codi;
		}

		public function getpaci_codi(){
			return $this->paci_codi;
		}

		public function getmedi_codi(){
			return $this->medi_codi;
		}

		public function getespe_codi(){
			return $this->espe_codi;
		}

		public function getsede_codi(){
			return $this->sede_codi;
		}

		public function getservi_codi(){
			return $this->servi_codi;
		}

		public function getcita_desc(){
			return $this->cita_desc;
		}

		
		

		public function consultar($cita_codi='') {
			if($cita_codi != ''):
				$this->query = "
				SELECT cita_codi, ase_codi, paci_codi, medi_codi, espe_codi, sede_codi, servi_codi, cita_desc  
				FROM tb_cita
				WHERE cita_codi = '$cita_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT cita_codi, a.ase_nomb, p.paci_nomb, m.medi_nomb, e.espe_nomb, s.sede_nomb, se.servi_nomb, cita_desc 
			FROM tb_cita as c 
			inner join tb_asesor as a ON (c.ase_codi = a.ase_codi) 
			inner join tb_paciente as p ON (c.paci_codi = p.paci_codi) 
			inner join tb_medico as m ON (c.medi_codi = m.medi_codi) 
			inner join tb_especialista as e ON (c.espe_codi = e.espe_codi) 
			inner join tb_sede as s ON (c.sede_codi = s.sede_codi) 
			inner join tb_servicio as se ON (c.servi_codi = se.servi_codi) 
			order by cita_codi
			";
			
			$this->obtener_resultados_query();
			return $this->rows;
			
		}

		
		public function nuevo($datos=array()) {
			if(array_key_exists('cita_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_cita
				(cita_codi, ase_codi, paci_codi, medi_codi, espe_codi, sede_codi, servi_codi, cita_desc)
				VALUES
				('$cita_codi', '$ase_codi', '$paci_codi', '$medi_codi', '$espe_codi', '$sede_codi', '$servi_codi', '$cita_desc')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$cita_codi= utf8_decode($cita_codi);
			$ase_codi= utf8_decode($ase_codi);
			$paci_codi= utf8_decode($paci_codi);
			$medi_codi= utf8_decode($medi_codi);
			$espe_codi= utf8_decode($espe_codi);
			$sede_codi= utf8_decode($sede_codi);
			$servi_codi= utf8_decode($servi_codi);
			$cita_desc= utf8_decode($cita_desc);

			$this->query = "
			UPDATE tb_cita
			SET ase_codi='$ase_codi',
			paci_codi='$paci_codi',
			medi_codi='$medi_codi',
			espe_codi='$espe_codi',
			sede_codi='$sede_codi',
			servi_codi='$servi_codi',
			cita_desc='$cita_desc' 
			WHERE cita_codi = '$cita_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($cita_codi='') {
			$this->query = "
			DELETE FROM tb_cita
			WHERE cita_codi = '$cita_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>