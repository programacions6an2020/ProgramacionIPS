   <div id="seccion-Cita">
    <div class="box-header">
        <i class="fa fa-building" aria-hidden="true">Gestion de Cita</i>
        
        <!-- tools box -->
        <div class="pull-right box-tools">
            <button class="btn btn-info btn-sm btncerrar2" data-toggle="tooltip" title="Cerrar"><i class="fa fa-times"></i></button>
        </div><!-- /. tools -->
    </div>
    <div class="box-body">

        <div align ="center">
                <div id="actual"> 
                </div>
        </div>

        <div class="panel-group"><div class="panel panel-info">
            <div class="panel-heading">Datos</div>
            <div class="panel-body">
    
                <form class="form-horizontal" role="form"  id="fCita">


                    <div class="form-group">
                        <label class="control-label col-sm-2" for="cita_codi">Codigo:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="cita_codi" name="cita_codi" placeholder="Ingrese Codigo"
                            value = "" readonly="true">
                        </div>
                    </div>

                    

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="ase_codi">Asesor:</label>
                        <div class="col-sm-10">
                            <select class="form-control" id="ase_codi" name="ase_codi">
                            
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="paci_codi">Paciente:</label>
                        <div class="col-sm-10">
                            <select class="form-control" id="paci_codi" name="paci_codi">
                            
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="medi_codi">Medico:</label>
                        <div class="col-sm-10">
                            <select class="form-control" id="medi_codi" name="medi_codi">
                            
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="espe_codi">Especialista:</label>
                        <div class="col-sm-10">
                            <select class="form-control" id="espe_codi" name="espe_codi">
                            
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="sede_codi">Sede:</label>
                        <div class="col-sm-10">
                            <select class="form-control" id="sede_codi" name="sede_codi">
                            
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="servi_codi">Servicio:</label>
                        <div class="col-sm-10">
                            <select class="form-control" id="servi_codi" name="servi_codi">
                            
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="cita_desc">Descripcion:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="cita_desc" name="cita_desc" placeholder="Ingrese Descripcion Cita"
                            value = "">
                        </div>
                    </div>


                     <div class="form-group">        
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="button" id="actualizar" data-toggle="tooltip" title="Actualizar Cita" class="btn btn-info">Actualizar</button>
                            <button type="button" id="cancelar" data-toggle="tooltip" title="Cancelar Edición" class="btn btn-success btncerrar2"> Cancelar </button>
                        </div>

                    </div>                    

                    <input type="hidden" id="editar" value="editar" name="accion"/>
            </fieldset>

        </form>
    </div>
    <input type="hidden" id="pagina" value="editar" name="editar"/>
</div>