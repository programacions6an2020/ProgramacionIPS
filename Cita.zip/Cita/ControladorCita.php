<?php
 
require_once 'cita_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $Cita = new Cita();
        $resultado = $Cita->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $Cita = new Cita();
        $resultado = $Cita->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $Cita = new Cita();
        $resultado = $Cita->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $Cita = new Cita();
        $Cita->consultar($datos['codigo']);

        if($Cita->getcita_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $Cita->getcita_codi(),
                'asesor' => $Cita->getase_codi(),
                'paciente' => $Cita->getpaci_codi(),
                'medico' => $Cita->getmedi_codi(),
                'especialista' => $Cita->getespe_codi(),
                'sede' => $Cita->getsede_codi(),
                'servicio' => $Cita->getservi_codi(),
                'descripcion' => $Cita->getcita_desc(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $Cita = new Cita();
        $listado = $Cita->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
