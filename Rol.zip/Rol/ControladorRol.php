<?php
 
require_once 'rol_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $Rol = new Rol();
        $resultado = $Rol->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $Rol = new Rol();
        $resultado = $Rol->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $Rol = new Rol();
        $resultado = $Rol->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $Rol = new Rol();
        $Rol->consultar($datos['codigo']);

        if($Rol->getrol_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $Rol->getrol_codi(),
                'rol' => $Rol->getrol_nomb(),
                'descripcion' => $Rol->getrol_desc(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $Rol = new Rol();
        $listado = $Rol->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
