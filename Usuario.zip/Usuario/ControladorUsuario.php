<?php
 
require_once 'usuario_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $Usuario = new Usuario();
        $resultado = $Usuario->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $Usuario = new Usuario();
		$resultado = $Usuario->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$Usuario = new Usuario();
		$resultado = $Usuario->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $Usuario = new Usuario();
        $Usuario->consultar($datos['codigo']);

        if($Usuario->getusu_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $Usuario->getusu_codi(),
                'Usuario' => $Usuario->getusu_nomb(),
                'edad' => $Usuario->getusu_edad(),
                'cuenta' => $Usuario->getusu_cuen(),
                'contra' => $Usuario->getusu_pass(),
                'rol' => $Usuario->getrol_codi(),
                'telefono' =>$Usuario->getusu_tel(),
                'direccion' =>$Usuario->getusu_dir(),
                'email' =>$Usuario->getusu_email(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $Usuario = new Usuario();
        $listado = $Usuario->lista();
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);    
        break;
}
?>
