<?php
    require_once("../modeloAbstractoDB.php");
    class Usuario extends ModeloAbstractoDB {
		private $usu_codi;
		private $usu_nomb;
		private $usu_edad;
		private $usu_cuen;
		private $usu_pass;
		private $rol_codi;
		private $usu_tel;
		private $usu_dir;
		private $usu_email;

		function __construct() {
			//$this->db_name = '';
		}

		public function getusu_codi(){
			return $this->usu_codi;
		}

		public function getusu_nomb(){
			return $this->usu_nomb;
		}
		
		public function getusu_edad(){
			return $this->usu_edad;
		}

		public function getusu_cuen(){
			return $this->usu_cuen;
		}
		public function getusu_pass(){
			return $this->usu_pass;
		}
		public function getusu_tel(){
			return $this->usu_tel;
		}
		public function getrol_codi(){
			return $this->rol_codi;
		}
		public function getusu_dir(){
			return $this->usu_dir;
		}
		public function getusu_email(){
			return $this->usu_email;
		}

		public function consultar($usu_codi='') {
			if($usu_codi !=''):
				$this->query = "
				SELECT usu_codi, usu_nomb, usu_edad, usu_cuen, usu_pass, rol_codi, usu_tel, usu_dir, usu_email 
				FROM tb_usuario
				WHERE usu_codi = '$usu_codi' order by usu_codi
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT usu_codi, usu_nomb, usu_edad, usu_cuen, usu_pass, m.rol_nomb, usu_tel, usu_dir, usu_email 
			FROM tb_usuario as c inner join tb_rol as m
			ON (c.rol_codi = m.rol_codi) order by usu_codi
			";
			
			$this->obtener_resultados_query();
			return $this->rows;
			
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('usu_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$usu_nomb= utf8_decode($usu_nomb);
				$this->query = "
					INSERT INTO tb_usuario
					(usu_codi, usu_nomb, usu_edad, usu_cuen, usu_pass, rol_codi, usu_tel, usu_dir, usu_email)
					VALUES
					(NULL, '$usu_nomb', '$usu_edad', '$usu_cuen', '$usu_pass', '$rol_codi', '$usu_tel', '$usu_dir', '$usu_email')
					";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$usu_nomb= utf8_decode($usu_nomb);
			$usu_codi= utf8_decode($usu_codi);
			$usu_edad= utf8_decode($usu_edad);
			$usu_cuen= utf8_decode($usu_cuen);
			$usu_pass= utf8_decode($usu_pass);
			$usu_tel= utf8_decode($usu_tel);
			$rol_codi= utf8_decode($rol_codi);
			$usu_dir= utf8_decode($usu_dir);
			$usu_email= utf8_decode($usu_email);
			$this->query = "
			UPDATE tb_usuario
			SET usu_nomb='$usu_nomb',
			usu_edad='$usu_edad',
			usu_cuen='$usu_cuen',
			usu_pass='$usu_pass',
			rol_codi='$rol_codi',
			usu_tel='$usu_tel',
			usu_dir='$usu_dir',
			usu_email='$usu_email' 
			WHERE usu_codi = '$usu_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($usu_codi='') {
			$this->query = "
			DELETE FROM tb_usuario
			WHERE usu_codi = '$usu_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>