<?php
	require_once('../modeloAbstractoDB.php');
	class Asesor extends ModeloAbstractoDB {
		public $ase_codi;
		public $ase_nomb;
		public $ase_edad;
		public $ase_tel;
		public $ase_dir;
		public $ase_email;
		
		
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getase_codi(){
			return $this->ase_codi;
		}

		public function getase_nomb(){
			return $this->ase_nomb;
		}

		public function getase_edad(){
			return $this->ase_edad;
		}

		public function getase_tel(){
			return $this->ase_tel;
		}

		public function getase_dir(){
			return $this->ase_dir;
		}

		public function getase_email(){
			return $this->ase_email;
		}


		
		

		public function consultar($ase_codi='') {
			if($ase_codi != ''):
				$this->query = "
				SELECT ase_codi, ase_nomb, ase_edad, ase_tel, ase_dir, ase_email 
				FROM tb_asesor
				WHERE ase_codi = '$ase_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT ase_codi, ase_nomb, ase_edad, ase_tel, ase_dir, ase_email  
			FROM tb_asesor ORDER BY ase_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		/*
		public function listapais() {
			$this->query = "
			SELECT ase_codi, ase_nomb 
			FROM tb_asesor as d order by ase_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}*/
		
		public function nuevo($datos=array()) {
			if(array_key_exists('ase_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_asesor
				(ase_codi, ase_nomb, ase_edad, ase_tel, ase_dir, ase_email )
				VALUES
				('$ase_codi', '$ase_nomb', '$ase_edad', '$ase_tel', '$ase_dir', '$ase_email' )
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$ase_nomb= utf8_decode($ase_nomb);
			$ase_codi= utf8_decode($ase_codi);
			$ase_edad= utf8_decode($ase_edad);
			
			$ase_tel= utf8_decode($ase_tel);
			$ase_dir= utf8_decode($ase_dir);
			$ase_email= utf8_decode($ase_email);
			
			$this->query = "
			UPDATE tb_asesor
			SET ase_nomb='$ase_nomb',
			ase_edad='$ase_edad',
			ase_tel='$ase_tel',
			ase_dir='$ase_dir',
			ase_email='$ase_email' 
			WHERE ase_codi = '$ase_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($ase_codi='') {
			$this->query = "
			DELETE FROM tb_asesor
			WHERE ase_codi = '$ase_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>