<?php
 
require_once 'asesor_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $Asesor = new Asesor();
        $resultado = $Asesor->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $Asesor = new Asesor();
        $resultado = $Asesor->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $Asesor = new Asesor();
        $resultado = $Asesor->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $Asesor = new Asesor();
        $Asesor->consultar($datos['codigo']);

        if($Asesor->getase_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $Asesor->getase_codi(),
                'Asesor' => $Asesor->getase_nomb(),
                'edad' => $Asesor->getase_edad(),
                'telefono' => $Asesor->getase_tel(),
                'direccion' => $Asesor->getase_dir(),
                'email' => $Asesor->getase_email(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $Asesor = new Asesor();
        $listado = $Asesor->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
