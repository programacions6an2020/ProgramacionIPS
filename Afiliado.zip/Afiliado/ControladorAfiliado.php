<?php
 
require_once 'afiliado_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $Afiliado = new Afiliado();
        $resultado = $Afiliado->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $Afiliado = new Afiliado();
        $resultado = $Afiliado->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $Afiliado = new Afiliado();
        $resultado = $Afiliado->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $Afiliado = new Afiliado();
        $Afiliado->consultar($datos['codigo']);

        if($Afiliado->getafi_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $Afiliado->getafi_codi(),
                'Afiliado' => $Afiliado->getafi_est(),
                'descripcion' => $Afiliado->getafi_desc(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $Afiliado = new Afiliado();
        $listado = $Afiliado->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
