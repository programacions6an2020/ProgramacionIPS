<?php
	require_once('../modeloAbstractoDB.php');
	class Afiliado extends ModeloAbstractoDB {
		public $afi_codi;
		public $afi_est;
		public $afi_desc;
		
		
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getafi_codi(){
			return $this->afi_codi;
		}

		public function getafi_est(){
			return $this->afi_est;
		}

		public function getafi_desc(){
			return $this->afi_desc;
		}

		
		

		public function consultar($afi_codi='') {
			if($afi_codi != ''):
				$this->query = "
				SELECT afi_codi, afi_est, afi_desc  
				FROM tb_afiliado
				WHERE afi_codi = '$afi_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT afi_codi, afi_est, afi_desc 
			FROM tb_afiliado ORDER BY afi_est
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		
		public function nuevo($datos=array()) {
			if(array_key_exists('afi_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_afiliado
				(afi_codi, afi_est, afi_desc)
				VALUES
				('$afi_codi', '$afi_est', '$afi_desc')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$afi_est= utf8_decode($afi_est);
			$afi_codi= utf8_decode($afi_codi);
			$afi_desc= utf8_decode($afi_desc);
			
			$this->query = "
			UPDATE tb_afiliado
			SET afi_est='$afi_est',
			afi_desc='$afi_desc' 
			WHERE afi_codi = '$afi_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($afi_codi='') {
			$this->query = "
			DELETE FROM tb_afiliado
			WHERE afi_codi = '$afi_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>