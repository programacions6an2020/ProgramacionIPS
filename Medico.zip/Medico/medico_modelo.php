<?php
	require_once('../modeloAbstractoDB.php');
	class Medico extends ModeloAbstractoDB {
		public $medi_codi;
		public $medi_nomb;
		public $medi_edad;
		public $medi_tel;
		public $medi_cel;
		public $medi_dir;
		public $medi_email;
		
		
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getmedi_codi(){
			return $this->medi_codi;
		}

		public function getmedi_nomb(){
			return $this->medi_nomb;
		}

		public function getmedi_edad(){
			return $this->medi_edad;
		}

		public function getmedi_tel(){
			return $this->medi_tel;
		}

		public function getmedi_cel(){
			return $this->medi_cel;
		}

		public function getmedi_dir(){
			return $this->medi_dir;
		}

		public function getmedi_email(){
			return $this->medi_email;
		}


		
		

		public function consultar($medi_codi='') {
			if($medi_codi != ''):
				$this->query = "
				SELECT medi_codi, medi_nomb, medi_edad, medi_tel, medi_cel, medi_dir, medi_email 
				FROM tb_medico
				WHERE medi_codi = '$medi_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT medi_codi, medi_nomb, medi_edad, medi_tel, medi_cel, medi_dir, medi_email  
			FROM tb_medico ORDER BY medi_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		/*
		public function listapais() {
			$this->query = "
			SELECT medi_codi, medi_nomb 
			FROM tb_medico as d order by medi_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}*/
		
		public function nuevo($datos=array()) {
			if(array_key_exists('medi_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_medico
				(medi_codi, medi_nomb, medi_edad, medi_tel, medi_cel, medi_dir, medi_email )
				VALUES
				('$medi_codi', '$medi_nomb', '$medi_edad', '$medi_tel', '$medi_cel', '$medi_dir', '$medi_email' )
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$medi_nomb= utf8_decode($medi_nomb);
			$medi_codi= utf8_decode($medi_codi);
			$medi_edad= utf8_decode($medi_edad);
			$medi_tel= utf8_decode($medi_tel);
			$medi_cel= utf8_decode($medi_cel);
			$medi_dir= utf8_decode($medi_dir);
			$medi_email= utf8_decode($medi_email);
			
			$this->query = "
			UPDATE tb_medico
			SET medi_nomb='$medi_nomb',
			medi_edad='$medi_edad',
			medi_tel='$medi_tel',
			medi_cel='$medi_cel',
			medi_dir='$medi_dir',
			medi_email='$medi_email' 
			WHERE medi_codi = '$medi_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($medi_codi='') {
			$this->query = "
			DELETE FROM tb_medico
			WHERE medi_codi = '$medi_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>