<?php
 
require_once 'medico_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $Medico = new Medico();
        $resultado = $Medico->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $Medico = new Medico();
        $resultado = $Medico->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $Medico = new Medico();
        $resultado = $Medico->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $Medico = new Medico();
        $Medico->consultar($datos['codigo']);

        if($Medico->getmedi_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $Medico->getmedi_codi(),
                'Medico' => $Medico->getmedi_nomb(),
                'edad' => $Medico->getmedi_edad(),
                'telefono' => $Medico->getmedi_tel(),
                'celular' => $Medico->getmedi_cel(),
                'direccion' => $Medico->getmedi_dir(),
                'email' => $Medico->getmedi_email(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $Medico = new Medico();
        $listado = $Medico->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
