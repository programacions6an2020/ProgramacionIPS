<?php
 
require_once 'empleado_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $Empleado = new Empleado();
        $resultado = $Empleado->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $Empleado = new Empleado();
		$resultado = $Empleado->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$Empleado = new Empleado();
		$resultado = $Empleado->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $Empleado = new Empleado();
        $Empleado->consultar($datos['codigo']);

        if($Empleado->getemple_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $Empleado->getemple_codi(),
                'Empleado' => $Empleado->getemple_nomb(),
                'edad' => $Empleado->getemple_edad(),
                'telefono' => $Empleado->getemple_tel(),
                'direccion' => $Empleado->getemple_dir(),
                'jefe' => $Empleado->getemple_jefe(),
                'sede' =>$Empleado->getsede_codi(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $Empleado = new Empleado();
        $listado = $Empleado->lista();
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);    
        break;
}
?>
