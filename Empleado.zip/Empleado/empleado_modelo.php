<?php
    require_once("../modeloAbstractoDB.php");
    class Empleado extends ModeloAbstractoDB {
		private $emple_codi;
		private $emple_nomb;
		private $emple_edad;
		private $emple_tel;
		private $emple_dir;
		private $emple_jefe;
		private $sede_codi;

		function __construct() {
			//$this->db_name = '';
		}

		public function getemple_codi(){
			return $this->emple_codi;
		}

		public function getemple_nomb(){
			return $this->emple_nomb;
		}
		
		public function getemple_edad(){
			return $this->emple_edad;
		}

		public function getemple_tel(){
			return $this->emple_tel;
		}
		public function getemple_dir(){
			return $this->emple_dir;
		}
		public function getemple_jefe(){
			return $this->emple_jefe;
		}
		public function getsede_codi(){
			return $this->sede_codi;
		}

		public function consultar($emple_codi='') {
			if($emple_codi !=''):
				$this->query = "
				SELECT emple_codi, emple_nomb, emple_edad, emple_tel, emple_dir, emple_jefe, sede_codi 
				FROM tb_empleado
				WHERE emple_codi = '$emple_codi' order by emple_codi
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT emple_codi, emple_nomb, emple_edad, emple_tel, emple_dir, emple_jefe, m.sede_nomb 
			FROM tb_empleado as c inner join tb_sede as m
			ON (c.sede_codi = m.sede_codi) order by emple_codi
			";
			
			$this->obtener_resultados_query();
			return $this->rows;
			
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('emple_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$emple_nomb= utf8_decode($emple_nomb);
				$this->query = "
					INSERT INTO tb_empleado
					(emple_codi, emple_nomb, emple_edad, emple_tel, emple_dir, emple_jefe, sede_codi)
					VALUES
					(NULL, '$emple_nomb', '$emple_edad', '$emple_tel', '$emple_dir', '$emple_jefe', '$sede_codi')
					";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$emple_nomb= utf8_decode($emple_nomb);
			$emple_codi= utf8_decode($emple_codi);
			$emple_edad= utf8_decode($emple_edad);
			$emple_tel= utf8_decode($emple_tel);
			$emple_dir= utf8_decode($emple_dir);
			$emple_jefe= utf8_decode($emple_jefe);
			$sede_codi= utf8_decode($sede_codi);
			$this->query = "
			UPDATE tb_empleado
			SET emple_nomb='$emple_nomb',
			emple_edad='$emple_edad',
			emple_tel='$emple_tel',
			emple_dir='$emple_dir',
			emple_jefe='$emple_jefe',
			sede_codi='$sede_codi' 
			WHERE emple_codi = '$emple_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($emple_codi='') {
			$this->query = "
			DELETE FROM tb_empleado
			WHERE emple_codi = '$emple_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>