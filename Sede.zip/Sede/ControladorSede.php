<?php
 
require_once 'sede_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $Sede = new Sede();
        $resultado = $Sede->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $Sede = new Sede();
        $resultado = $Sede->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $Sede = new Sede();
        $resultado = $Sede->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $Sede = new Sede();
        $Sede->consultar($datos['codigo']);

        if($Sede->getsede_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $Sede->getsede_codi(),
                'sede' => $Sede->getsede_nomb(),
                'ciudad' => $Sede->getciu_codi(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $Sede = new Sede();
        $listado = $Sede->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
