<?php
	require_once('../modeloAbstractoDB.php');
	class Sede extends ModeloAbstractoDB {
		public $sede_codi;
		public $sede_nomb;
		public $ciu_codi;
		
		
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getsede_codi(){
			return $this->sede_codi;
		}

		public function getsede_nomb(){
			return $this->sede_nomb;
		}

		public function getciu_codi(){
			return $this->ciu_codi;
		}

		
		

		public function consultar($sede_codi='') {
			if($sede_codi != ''):
				$this->query = "
				SELECT sede_codi, sede_nomb, ciu_codi 
				FROM tb_sede
				WHERE sede_codi = '$sede_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT sede_codi, sede_nomb, m.ciu_nomb
			FROM tb_sede as c inner join tb_ciudad as m
			ON (c.ciu_codi = m.ciu_codi) order by sede_codi
			";
			
			$this->obtener_resultados_query();
			return $this->rows;
			
		}

		
		public function nuevo($datos=array()) {
			if(array_key_exists('sede_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_sede
				(sede_codi, sede_nomb, ciu_codi)
				VALUES
				('$sede_codi', '$sede_nomb', '$ciu_codi')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$sede_nomb= utf8_decode($sede_nomb);
			$sede_codi= utf8_decode($sede_codi);
			$ciu_codi= utf8_decode($ciu_codi);

			$this->query = "
			UPDATE tb_sede
			SET sede_nomb='$sede_nomb',
			ciu_codi='$ciu_codi' 
			WHERE sede_codi = '$sede_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($sede_codi='') {
			$this->query = "
			DELETE FROM tb_sede
			WHERE sede_codi = '$sede_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>