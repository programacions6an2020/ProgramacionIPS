<?php
    require_once("../modeloAbstractoDB.php");
    class ciudad extends ModeloAbstractoDB {
		private $ciu_codi;
		private $ciu_nomb;
		private $pais_codi;
		
		function __construct() {
			//$this->db_name = '';
		}

		public function getciu_codi(){
			return $this->ciu_codi;
		}

		public function getciu_nomb(){
			return $this->ciu_nomb;
		}
		
		public function getpais_codi(){
			return $this->pais_codi;
		}

		public function consultar($ciu_codi='') {
			if($ciu_codi !=''):
				$this->query = "
				SELECT ciu_codi, ciu_nomb, pais_codi
				FROM tb_ciudad
				WHERE ciu_codi = '$ciu_codi' order by ciu_codi
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT ciu_codi, ciu_nomb, m.pais_nomb
			FROM tb_ciudad as c inner join tb_pais as m
			ON (c.pais_codi = m.pais_codi) order by ciu_codi
			";
			
			$this->obtener_resultados_query();
			return $this->rows;
			
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('ciu_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$ciu_nomb= utf8_decode($ciu_nomb);
				$this->query = "
					INSERT INTO tb_ciudad
					(ciu_codi, ciu_nomb, pais_codi)
					VALUES
					(NULL, '$ciu_nomb', '$pais_codi')
					";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$ciu_nomb= utf8_decode($ciu_nomb);
			$this->query = "
			UPDATE tb_ciudad
			SET ciu_nomb='$ciu_nomb',
			pais_codi='$pais_codi'
			WHERE ciu_codi = '$ciu_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($ciu_codi='') {
			$this->query = "
			DELETE FROM tb_ciudad
			WHERE ciu_codi = '$ciu_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>