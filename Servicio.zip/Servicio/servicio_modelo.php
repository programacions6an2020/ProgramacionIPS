<?php
	require_once('../modeloAbstractoDB.php');
	class Servicio extends ModeloAbstractoDB {
		public $servi_codi;
		public $servi_nomb;
		public $servi_desc;
		
		
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getservi_codi(){
			return $this->servi_codi;
		}

		public function getservi_nomb(){
			return $this->servi_nomb;
		}

		public function getservi_desc(){
			return $this->servi_desc;
		}

		
		

		public function consultar($servi_codi='') {
			if($servi_codi != ''):
				$this->query = "
				SELECT servi_codi, servi_nomb, servi_desc 
				FROM tb_servicio
				WHERE servi_codi = '$servi_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT servi_codi, servi_nomb, servi_desc 
			FROM tb_servicio ORDER BY servi_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		/*
		public function listapais() {
			$this->query = "
			SELECT servi_codi, servi_nomb 
			FROM tb_servicio as d order by servi_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}*/
		
		public function nuevo($datos=array()) {
			if(array_key_exists('servi_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_servicio
				(servi_codi, servi_nomb, servi_desc)
				VALUES
				('$servi_codi', '$servi_nomb', '$servi_desc')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$servi_nomb= utf8_decode($servi_nomb);
			$servi_codi= utf8_decode($servi_codi);
			$servi_desc= utf8_decode($servi_desc);
			
			$this->query = "
			UPDATE tb_servicio
			SET servi_nomb='$servi_nomb',
			servi_desc='$servi_desc' 
			WHERE servi_codi = '$servi_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($servi_codi='') {
			$this->query = "
			DELETE FROM tb_servicio
			WHERE servi_codi = '$servi_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>