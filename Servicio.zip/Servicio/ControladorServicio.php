<?php
 
require_once 'servicio_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $servicio = new Servicio();
        $resultado = $servicio->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $servicio = new Servicio();
        $resultado = $servicio->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $servicio = new Servicio();
        $resultado = $servicio->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $servicio = new Servicio();
        $servicio->consultar($datos['codigo']);

        if($servicio->getservi_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $servicio->getservi_codi(),
                'servicio' => $servicio->getservi_nomb(),
                'descripcion' => $servicio->getservi_desc(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $servicio = new Servicio();
        $listado = $servicio->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
